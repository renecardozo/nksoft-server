<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Materia;
use Illuminate\Database\QueryException;

class MateriaController extends Controller
{

    
    //
    public function store(Request $request)
    {
        $materia = new Materia();
        $materia->id_materia = $request->id_materia;
        $materia->codigo = $request->codigo;
        $materia->materia = $request->materia;
        $materia->grupo = $request->grupo;
        $materia->departamento = $request->departamento;
        $materia->save();
    }

    public function crearMateria(Request $request)
    {
        $materia = new Materia();
        $materia->id_materia = $request->id_materia;
        $materia->codigo = $request->codigo;
        $materia->materia = $request->materia;
        $materia->grupo = $request->grupo;
        $materia->departamento = $request->departamento;
        $materia->save();
    }

    public function guardar(Request $request)
    {
        $materia = new Materia();
        $materia->id_materia = $request->id_materia;
        $materia->codigo = $request->codigo;
        $materia->materia = $request->materia;
        $materia->grupo = $request->grupo;
        //$materia->docente = $request->docente;
        $materia->departamento = $request->departamento;
        $materia->save();
    }



    public function index()
    {
        $materias = Materia::all();
        return $materias;
    }


    public function get(){
        try{
            $data = Materia::get();
            return response()->json($data, 200);
        } catch (\Throwable $th){
            return response()->json(['error' => $th -> getMessage()],500);
        }
    }

    public function create(Request $request){
        try{
            $data['id_materia']=$request['id_materia'];
            $data['codigo']=$request['codigo'];
            $data['materia']=$request['materia'];
            $data['grupo']=$request['grupo'];
            $data['departamento']=$request['departamento'];
            $res = Materia::create($data);
            return response()->json($res, 200);
        }catch(\Throwable $th){
            return response()->json(['error' => $th -> getMessage()],500);
        }
    }

    public function verificar(Request $request)
    {
        
        $materia = $request->input('materia');
        $grupo = $request->input('grupo');

        $duplicados = Materia::where('materia', $materia)
                             ->where('grupo', $grupo)
                             ->exists();

        return response()->json(['duplicados' => $duplicados]);
    }


    public function getById($id){
        try{
            $data = Materia::find($id);
            return response()->json($data,200);
        }catch(\Throwable $th){
            return response()->json(['error' => $th -> getMessage()],500);
        }
    }

    public function update(Request $request, $id){
        try{
            $data['id_materia']=$request['id_materia'];
            $data['codigo']=$request['codigo'];
            $data['materia']=$request['materia'];
            $data['grupo']=$request['grupo'];
            $data['departamento']=$request['departamento'];
            Materia::find($id)->update($data);
            $res = Materia::find($id);
            return response()->json($data,200);
        }catch(\Throwable $th){
            return response()->json(['error' => $th -> getMessage()],500);
        }
    }

    public function delete($id){
        try{
           
            $res = Materia::find($id)->delete();
            return response()->json(["deleted"=> $res],200);
        }catch(\Throwable $th){
            return response()->json(['error' => $th -> getMessage()],500);
        }

    }

    public function show($id)
    {
        try {
            $materia = Materia::find($id);
            return response()->json([
                'success' => true,
                'data' => $materia
            ]);
        } catch (QueryException $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener la Materia: ' . $e->getMessage()
            ], 500);
        }
    }
}
